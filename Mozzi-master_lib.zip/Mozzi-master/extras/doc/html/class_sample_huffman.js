var class_sample_huffman =
[
    [ "SampleHuffman", "class_sample_huffman.html#a8587f641949024cd5aad7bfc1715adff", null ],
    [ "next", "class_sample_huffman.html#a8ec7bbb21f5cf0e780611a7539e86695", null ],
    [ "setLoopingOff", "class_sample_huffman.html#a040bfc55c19bbaa6cc42331be3646c8a", null ],
    [ "setLoopingOn", "class_sample_huffman.html#a01f9bfb513da0374fe78c12300b69760", null ],
    [ "start", "class_sample_huffman.html#a15ead859261d3d916d700b75f4626f15", null ]
];